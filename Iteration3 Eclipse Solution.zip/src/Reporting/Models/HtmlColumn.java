package Reporting.Models;

public class HtmlColumn {
	public HtmlColumn(String columnValue)
	{
		columnName = columnValue;
	}
	public String columnName;	
}
