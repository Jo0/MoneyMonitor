package Core.Models;

public class ExchangeRate {

}
