package Core.Models;

public class User {

}
